package entity;


import lombok.Data;

/**
 * @author ：ZXY
 * @date ：Created in 2020/5/12 21:32
 * @description：
 */


@Data
public class Account {
    private  Integer id;
    private  String username;
    private  String password;
}
